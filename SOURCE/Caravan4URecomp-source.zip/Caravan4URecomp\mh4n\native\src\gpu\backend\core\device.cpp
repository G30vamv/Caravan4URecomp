// The device: probing every physical device, choosing one by capability, enabling only what the
// capabilities use, applying the mask, and the Backend's read-only accessors (N2-26).
#include <algorithm>
#include <cstdlib>
#include <mutex>
#include <set>
#include <string>
#include <string_view>

#include <fmt/format.h>

#include "gpu/backend/core/impl.h"
#include "gpu/backend/driver_hooks.h"
#include "mh4n/log.h"
#include "mh4n/spirv_target.h"

namespace mh4n::gpu::rhi {

namespace {

constexpr u32 MakeApi(u32 major, u32 minor) {
    return (major << 22) | (minor << 12);
}

// Everything the choice and the capabilities need to know about one physical device.
struct Probe {
    core::DeviceCandidate candidate;
    Capabilities caps; // before the mask
    std::set<std::string> extensions;
    VkPhysicalDeviceFeatures features = {};
    VkPhysicalDeviceLimits limits = {};
    bool present_id = false;
    bool present_wait = false;
    bool can_present = false;
    u32 queue_family_count = 0;
};

core::DeviceType ToDeviceType(VkPhysicalDeviceType type) {
    switch (type) {
    case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU: return core::DeviceType::Discrete;
    case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU: return core::DeviceType::Integrated;
    case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU: return core::DeviceType::Virtual;
    case VK_PHYSICAL_DEVICE_TYPE_CPU: return core::DeviceType::Cpu;
    default: return core::DeviceType::Other;
    }
}

struct Chain {
    void* head = nullptr;
    template <typename T> void Add(T& structure, VkStructureType type) {
        structure.sType = type;
        structure.pNext = head;
        head = &structure;
    }
};

u32 CountBits(const Capabilities& caps, CapabilityMask mask) {
    u32 bits = 0;
    for (u32 i = 0; i < kCapCount; ++i) {
        const Cap cap = static_cast<Cap>(i);
        bits += (caps.Has(cap) && !mask.Has(cap)) ? 1 : 0;
    }
    return bits;
}

Probe ProbePhysicalDevice(VkPhysicalDevice device, u32 index, VkSurfaceKHR surface) {
    Probe probe;
    Capabilities& caps = probe.caps;
    caps.device_index = index;

    VkPhysicalDeviceProperties props = {};
    vkGetPhysicalDeviceProperties(device, &props);
    probe.limits = props.limits;
    vkGetPhysicalDeviceFeatures(device, &probe.features);
    caps.device_name = props.deviceName;
    caps.api_version = props.apiVersion;
    caps.vendor_id = props.vendorID;
    caps.timestamp_period = props.limits.timestampPeriod;
    caps.max_texel_buffer_elements = props.limits.maxTexelBufferElements;
    caps.uniform_buffer_offset_alignment = static_cast<u32>(props.limits.minUniformBufferOffsetAlignment);
    caps.storage_buffer_offset_alignment = static_cast<u32>(props.limits.minStorageBufferOffsetAlignment);
    caps.max_uniform_buffer_range = props.limits.maxUniformBufferRange;
    caps.max_storage_buffer_range = props.limits.maxStorageBufferRange;
    caps.geometry_shader = probe.features.geometryShader != VK_FALSE;
    caps.clip_distance = probe.features.shaderClipDistance != VK_FALSE;

    u32 count = 0;
    vkEnumerateDeviceExtensionProperties(device, nullptr, &count, nullptr);
    std::vector<VkExtensionProperties> listed(count);
    vkEnumerateDeviceExtensionProperties(device, nullptr, &count, listed.data());
    for (const VkExtensionProperties& extension : listed) {
        probe.extensions.insert(extension.extensionName);
    }
    const auto has = [&](const char* name) { return probe.extensions.count(name) != 0; };
    const u32 api = props.apiVersion;
    caps.portability_subset = has(VK_KHR_PORTABILITY_SUBSET_EXTENSION_NAME);

    // Properties: the driver's id and name, the portability subset's stride alignment.
    VkPhysicalDeviceDriverProperties driver = {};
    VkPhysicalDevicePortabilitySubsetPropertiesKHR subset_props = {};
    if (api >= MakeApi(1, 1)) {
        Chain chain;
        if (api >= MakeApi(1, 2) || has(VK_KHR_DRIVER_PROPERTIES_EXTENSION_NAME)) {
            chain.Add(driver, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES);
        }
        if (caps.portability_subset) {
            chain.Add(subset_props, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PORTABILITY_SUBSET_PROPERTIES_KHR);
        }
        VkPhysicalDeviceProperties2 props2 = {};
        props2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
        props2.pNext = chain.head;
        vkGetPhysicalDeviceProperties2(device, &props2);
    }
    caps.driver_id = static_cast<u32>(driver.driverID);
    caps.driver_name = driver.driverName;
    caps.stride_alignment = (caps.portability_subset && subset_props.minVertexInputBindingStrideAlignment > 0)
                                ? subset_props.minVertexInputBindingStrideAlignment
                                : 1;
    caps.apple = core::IsAppleDriver(caps.driver_id, caps.driver_name, caps.vendor_id);
    caps.primitive_restart_always_on = caps.apple; // inference (MoltenVK always restarts; KosmicKrisp: unknown)

    // Features: only the structures the device can answer are chained.
    VkPhysicalDeviceTimelineSemaphoreFeatures timeline = {};
    VkPhysicalDeviceFragmentShaderInterlockFeaturesEXT interlock = {};
    VkPhysicalDeviceIndexTypeUint8FeaturesEXT uint8 = {};
    VkPhysicalDeviceCustomBorderColorFeaturesEXT border = {};
    VkPhysicalDevicePortabilitySubsetFeaturesKHR subset = {};
    VkPhysicalDeviceDynamicRenderingFeatures dynamic_rendering = {};
    VkPhysicalDeviceGraphicsPipelineLibraryFeaturesEXT library = {};
    VkPhysicalDeviceExtendedDynamicState3FeaturesEXT eds3 = {};
    VkPhysicalDevicePresentIdFeaturesKHR present_id = {};
    VkPhysicalDevicePresentWaitFeaturesKHR present_wait = {};
    const bool have_timeline = api >= MakeApi(1, 2) || has(VK_KHR_TIMELINE_SEMAPHORE_EXTENSION_NAME);
    const bool have_dynamic_rendering = api >= MakeApi(1, 3) || has(VK_KHR_DYNAMIC_RENDERING_EXTENSION_NAME);
    const bool have_present = has(VK_KHR_PRESENT_ID_EXTENSION_NAME) && has(VK_KHR_PRESENT_WAIT_EXTENSION_NAME);
    if (api >= MakeApi(1, 1)) {
        Chain chain;
        if (have_timeline) chain.Add(timeline, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES);
        if (has(VK_EXT_FRAGMENT_SHADER_INTERLOCK_EXTENSION_NAME))
            chain.Add(interlock, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FRAGMENT_SHADER_INTERLOCK_FEATURES_EXT);
        if (has(VK_EXT_INDEX_TYPE_UINT8_EXTENSION_NAME))
            chain.Add(uint8, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_INDEX_TYPE_UINT8_FEATURES_EXT);
        if (has(VK_EXT_CUSTOM_BORDER_COLOR_EXTENSION_NAME))
            chain.Add(border, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_CUSTOM_BORDER_COLOR_FEATURES_EXT);
        if (caps.portability_subset)
            chain.Add(subset, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PORTABILITY_SUBSET_FEATURES_KHR);
        if (have_dynamic_rendering)
            chain.Add(dynamic_rendering, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DYNAMIC_RENDERING_FEATURES);
        if (has(VK_EXT_GRAPHICS_PIPELINE_LIBRARY_EXTENSION_NAME))
            chain.Add(library, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_GRAPHICS_PIPELINE_LIBRARY_FEATURES_EXT);
        if (has(VK_EXT_EXTENDED_DYNAMIC_STATE_3_EXTENSION_NAME))
            chain.Add(eds3, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_EXTENDED_DYNAMIC_STATE_3_FEATURES_EXT);
        if (have_present) {
            chain.Add(present_id, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_ID_FEATURES_KHR);
            chain.Add(present_wait, VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PRESENT_WAIT_FEATURES_KHR);
        }
        VkPhysicalDeviceFeatures2 features2 = {};
        features2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2;
        features2.pNext = chain.head;
        vkGetPhysicalDeviceFeatures2(device, &features2);
        probe.features = features2.features;
    }
    // (Vulkan 1.2 and newer only, from the probe on: every copy of the caps agrees, as MH4N_RHI_MASK=timeline does; plume
    // enables timelines as core, so a 1.1 driver has no vkGetSemaphoreCounterValue / vkWaitSemaphores: 4u-native #1, #6)
    caps.timeline = timeline.timelineSemaphore != VK_FALSE && api >= MakeApi(1, 2);
    caps.interlock = interlock.fragmentShaderPixelInterlock != VK_FALSE;
    caps.index_uint8 = uint8.indexTypeUint8 != VK_FALSE;
    caps.custom_border_color = border.customBorderColors != VK_FALSE;
    // Fans are core on a full device; the portability subset says whether it has them.
    caps.triangle_fans = caps.portability_subset ? subset.triangleFans != VK_FALSE : true;
    caps.logic_op = probe.features.logicOp != VK_FALSE;
    caps.dynamic_rendering = dynamic_rendering.dynamicRendering != VK_FALSE;
    caps.pipeline_library = library.graphicsPipelineLibrary != VK_FALSE;
    caps.eds3_blend = eds3.extendedDynamicState3ColorBlendEnable && eds3.extendedDynamicState3ColorBlendEquation &&
                      eds3.extendedDynamicState3ColorWriteMask && eds3.extendedDynamicState3LogicOpEnable;
    probe.present_id = present_id.presentId != VK_FALSE;
    probe.present_wait = present_wait.presentWait != VK_FALSE;
    caps.present_wait = probe.present_id && probe.present_wait;

    // Formats.
    const auto format_has = [&](VkFormat format, VkFormatFeatureFlags needed) {
        VkFormatProperties format_props = {};
        vkGetPhysicalDeviceFormatProperties(device, format, &format_props);
        return (format_props.optimalTilingFeatures & needed) == needed;
    };
    caps.d24s8 = format_has(VK_FORMAT_D24_UNORM_S8_UINT,
                            VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT | VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT);
    caps.bc7 = probe.features.textureCompressionBC != VK_FALSE &&
               format_has(VK_FORMAT_BC7_UNORM_BLOCK, VK_FORMAT_FEATURE_SAMPLED_IMAGE_BIT);

    // Memory: the host can write device memory directly when a host-visible, device-local type sits in
    // a heap as large as the biggest device-local heap (unified memory, resizable BAR).
    VkPhysicalDeviceMemoryProperties memory = {};
    vkGetPhysicalDeviceMemoryProperties(device, &memory);
    VkDeviceSize biggest_device_heap = 0;
    for (u32 i = 0; i < memory.memoryHeapCount; ++i) {
        if (memory.memoryHeaps[i].flags & VK_MEMORY_HEAP_DEVICE_LOCAL_BIT) {
            biggest_device_heap = std::max(biggest_device_heap, memory.memoryHeaps[i].size);
        }
    }
    constexpr VkMemoryPropertyFlags kDirect = VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT | VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
    for (u32 i = 0; i < memory.memoryTypeCount; ++i) {
        if ((memory.memoryTypes[i].propertyFlags & kDirect) == kDirect &&
            memory.memoryHeaps[memory.memoryTypes[i].heapIndex].size >= biggest_device_heap) {
            caps.direct_upload = true;
        }
    }

    // Queues: the family plume wants (graphics, compute and transfer), and whether one can present.
    vkGetPhysicalDeviceQueueFamilyProperties(device, &probe.queue_family_count, nullptr);
    std::vector<VkQueueFamilyProperties> families(probe.queue_family_count);
    vkGetPhysicalDeviceQueueFamilyProperties(device, &probe.queue_family_count, families.data());
    // The family the vendored backend picks has graphics, compute and transfer: the policy must agree with that
    // pick, so it asks for the same three bits (relaxing it is a patch of the vendored queue).
    bool graphics = false;
    probe.can_present = (surface == VK_NULL_HANDLE);
    for (u32 i = 0; i < families.size(); ++i) {
        if (!core::IsDirectQueueFamily(families[i].queueFlags)) {
            continue;
        }
        graphics = true;
        if (surface != VK_NULL_HANDLE) {
            VkBool32 supported = VK_FALSE;
            if (vkGetPhysicalDeviceSurfaceSupportKHR(device, i, surface, &supported) == VK_SUCCESS && supported) {
                probe.can_present = true;
            }
        }
    }

    if (surface != VK_NULL_HANDLE && !has(VK_KHR_SWAPCHAIN_EXTENSION_NAME)) {
        probe.can_present = false; // a surface needs the swapchain extension
    }

    core::DeviceCandidate& candidate = probe.candidate;
    candidate.index = index;
    candidate.name = caps.device_name;
    candidate.driver_name = caps.driver_name;
    candidate.type = ToDeviceType(props.deviceType);
    candidate.has_graphics_queue = graphics;
    candidate.fragment_stores_and_atomics = probe.features.fragmentStoresAndAtomics != VK_FALSE;
    candidate.can_present = probe.can_present;
    return probe;
}

// Turns the bits of the mask off.
void ApplyMask(Capabilities& caps, CapabilityMask mask) {
    if (mask.Has(Cap::D24S8)) caps.d24s8 = false;
    if (mask.Has(Cap::Interlock)) caps.interlock = false;
    if (mask.Has(Cap::IndexUint8)) caps.index_uint8 = false;
    if (mask.Has(Cap::CustomBorderColor)) caps.custom_border_color = false;
    if (mask.Has(Cap::TriangleFans)) caps.triangle_fans = false;
    if (mask.Has(Cap::LogicOp)) caps.logic_op = false;
    if (mask.Has(Cap::DynamicRendering)) caps.dynamic_rendering = false;
    if (mask.Has(Cap::PipelineLibrary)) caps.pipeline_library = false;
    if (mask.Has(Cap::Eds3Blend)) caps.eds3_blend = false;
    if (mask.Has(Cap::Bc7)) caps.bc7 = false;
    if (mask.Has(Cap::Timeline)) caps.timeline = false;
    if (mask.Has(Cap::PresentWait)) caps.present_wait = false;
    if (mask.Has(Cap::DirectUpload)) caps.direct_upload = false;
    if (mask.Has(Cap::GeometryShader)) caps.geometry_shader = false;
    caps.masked = mask;
}

} // namespace

// ---- Backend::Impl -------------------------------------------------------------------------------

Backend::Impl::~Impl() {
    if (device != nullptr && device->vk != VK_NULL_HANDLE) {
        vkDeviceWaitIdle(device->vk);
    }
    // Members go in reverse order: the other modules' slots, the framebuffers, the lists, the semaphore,
    // the queue, the device, then the instance.
}

Backend::Backend(std::shared_ptr<Impl> impl) : impl_(std::move(impl)) {}
Backend::~Backend() = default;

const Capabilities& Backend::Caps() const {
    return impl_->caps;
}
bool Backend::PresentWaitAvailable() const {
    return impl_->present_wait_available;
}
bool Backend::PresentWaitMeasuresDisplay() const {
    return impl_->present_wait_measures_display;
}
bool Backend::DisplayTimingAvailable() const {
    return impl_->display_timing_available;
}
const std::vector<std::string>& Backend::EnabledExtensions() const {
    return impl_->enabled_extensions;
}
bool Backend::HasSurface() const {
    return impl_->surface != VK_NULL_HANDLE;
}
Backend::MemoryUse Backend::Memory() const {
    MemoryUse use;
    if (impl_->device == nullptr || impl_->device->allocator == VK_NULL_HANDLE) {
        return use;
    }
    VmaBudget budgets[VK_MAX_MEMORY_HEAPS] = {};
    vmaGetHeapBudgets(impl_->device->allocator, budgets);
    const VkPhysicalDeviceMemoryProperties* properties = nullptr;
    vmaGetMemoryProperties(impl_->device->allocator, &properties);
    for (u32 heap = 0; properties != nullptr && heap < properties->memoryHeapCount; ++heap) {
        use.block_bytes += budgets[heap].statistics.blockBytes;
        use.allocation_bytes += budgets[heap].statistics.allocationBytes;
        use.blocks += budgets[heap].statistics.blockCount;
        use.allocations += budgets[heap].statistics.allocationCount;
    }
    return use;
}

namespace {
// An RGBA8 image of the textures' kind (optimal tiling, sampled, a transfer's source and destination), `rows` of 1024
// pixels.
VkImageCreateInfo TextureLikeImage(u32 rows) {
    VkImageCreateInfo info{};
    info.sType = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO;
    info.imageType = VK_IMAGE_TYPE_2D;
    info.format = VK_FORMAT_R8G8B8A8_UNORM;
    info.extent = {1024, std::max<u32>(1, rows), 1};
    info.mipLevels = 1;
    info.arrayLayers = 1;
    info.samples = VK_SAMPLE_COUNT_1_BIT;
    info.tiling = VK_IMAGE_TILING_OPTIMAL;
    info.usage = VK_IMAGE_USAGE_SAMPLED_BIT | VK_IMAGE_USAGE_TRANSFER_DST_BIT | VK_IMAGE_USAGE_TRANSFER_SRC_BIT;
    info.sharingMode = VK_SHARING_MODE_EXCLUSIVE;
    info.initialLayout = VK_IMAGE_LAYOUT_UNDEFINED;
    return info;
}
}  // namespace

void Backend::ReserveImageMemory(u64 bytes) const {
    if (impl_->device == nullptr || impl_->device->allocator == VK_NULL_HANDLE) {
        return;
    }
    const VkImageCreateInfo info = TextureLikeImage(static_cast<u32>(std::max<u64>(1, bytes / (1024 * 4))));
    VmaAllocationCreateInfo allocation_info{};
    allocation_info.preferredFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;  // (as plume's VulkanTexture asks)
    VkImage image = VK_NULL_HANDLE;
    VmaAllocation allocation = VK_NULL_HANDLE;
    if (vmaCreateImage(impl_->device->allocator, &info, &allocation_info, &image, &allocation, nullptr) == VK_SUCCESS) {
        vmaDestroyImage(impl_->device->allocator, image, allocation);
    }
}

u64 Backend::FreeImageMemory() const {
    if (impl_->device == nullptr || impl_->device->allocator == VK_NULL_HANDLE) {
        return 0;
    }
    const VkImageCreateInfo info = TextureLikeImage(256);
    VmaAllocationCreateInfo allocation_info{};
    allocation_info.preferredFlags = VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
    u32 type = 0;
    if (vmaFindMemoryTypeIndexForImageInfo(impl_->device->allocator, &info, &allocation_info, &type) != VK_SUCCESS) {
        return 0;
    }
    VmaTotalStatistics stats{};
    vmaCalculateStatistics(impl_->device->allocator, &stats);
    const VmaStatistics& s = stats.memoryType[type].statistics;
    return s.blockBytes > s.allocationBytes ? s.blockBytes - s.allocationBytes : 0;
}

// ---- CreateBackend -------------------------------------------------------------------------------

namespace {

// The last handle CreateBackend returned is going away. What the modules keep for the life of a backend (the readback
// module's pipelines, binding sets and buffers, the targets module's staging buffers, the sync module's retired objects)
// holds Backend::Impl through a strong reference (every Buffer, BindingSet and Pipeline does), and Impl holds the slots that
// hold them: a cycle that would keep the device and the instance alive until the process ends (on the RX 6700 XT, nine
// such devices alive when the tenth was lost). So the slots are released here, once the GPU is idle, in the order the
// destructor of Impl would have used; a slot made again later (an object that outlives the handle) is made empty on first use.
void ReleaseWithLastHandle(Backend* backend) {
    Backend::Impl& impl = backend->impl();
    if (impl.device != nullptr && impl.device->vk != VK_NULL_HANDLE) {
        vkDeviceWaitIdle(impl.device->vk);
    }
    impl.state.reset();
    impl.readback.reset();
    impl.sync.reset();
    impl.targets.reset();
    delete backend;
}

// ---- a PowerVR: one driver compile at a time ----
// Its shader compiler crashed building two things at once (libusc.so on a GE8300 building the ubershader; the saved list
// built on a worker while the renderer built its own misses), so since 0.1.6 a PowerVR built every pipeline on the
// renderer thread when first drawn, with no list: the game stopped at every new effect, in every session (4u-native
// #48, Helio G35 / GE8320). As MHGU for Android does on a PowerVR (runtime/nvn/vulkan/device.c one_compiler_install):
// every call into the driver's compiler takes one lock, from any thread (the list's worker, the renderer's own misses,
// the pipeline check), and the cache's data is not read while one runs. Never two at once. MH4N_ONE_COMPILE=1 does it on
// any GPU, =0 never (a test aid).
std::mutex g_compiler_lock;
PFN_vkCreateShaderModule g_driver_create_module = nullptr;
PFN_vkCreateGraphicsPipelines g_driver_create_graphics = nullptr;
PFN_vkCreateComputePipelines g_driver_create_compute = nullptr;
PFN_vkGetPipelineCacheData g_driver_cache_data = nullptr;

VKAPI_ATTR VkResult VKAPI_CALL OneCreateModule(VkDevice d, const VkShaderModuleCreateInfo* ci, const VkAllocationCallbacks* a,
                                               VkShaderModule* m) {
    std::lock_guard lock(g_compiler_lock);
    return g_driver_create_module(d, ci, a, m);
}
VKAPI_ATTR VkResult VKAPI_CALL OneCreateGraphics(VkDevice d, VkPipelineCache c, uint32_t n, const VkGraphicsPipelineCreateInfo* ci,
                                                 const VkAllocationCallbacks* a, VkPipeline* p) {
    std::lock_guard lock(g_compiler_lock);
    return g_driver_create_graphics(d, c, n, ci, a, p);
}
VKAPI_ATTR VkResult VKAPI_CALL OneCreateCompute(VkDevice d, VkPipelineCache c, uint32_t n, const VkComputePipelineCreateInfo* ci,
                                                const VkAllocationCallbacks* a, VkPipeline* p) {
    std::lock_guard lock(g_compiler_lock);
    return g_driver_create_compute(d, c, n, ci, a, p);
}
VKAPI_ATTR VkResult VKAPI_CALL OneCacheData(VkDevice d, VkPipelineCache c, size_t* size, void* data) {
    std::lock_guard lock(g_compiler_lock);
    return g_driver_cache_data(d, c, size, data);
}

// (on the thread that made the device, before anything of it is compiled; volk's pointers are process-wide, and an
// instance made again loads them again: put back each time)
void OneCompileAtATime(const Capabilities& c) {
    constexpr u32 kVendorImagination = 0x1010, kDriverImagination = 7;  // (VkDriverId)
    const char* env = std::getenv("MH4N_ONE_COMPILE");
    const bool on = env != nullptr && (*env == '0' || *env == '1')
                        ? *env == '1'
                        : c.vendor_id == kVendorImagination || c.driver_id == kDriverImagination;
    if (!on || vkCreateGraphicsPipelines == OneCreateGraphics) return;
    g_driver_create_module = vkCreateShaderModule, vkCreateShaderModule = OneCreateModule;
    g_driver_create_graphics = vkCreateGraphicsPipelines, vkCreateGraphicsPipelines = OneCreateGraphics;
    g_driver_create_compute = vkCreateComputePipelines, vkCreateComputePipelines = OneCreateCompute;
    g_driver_cache_data = vkGetPipelineCacheData, vkGetPipelineCacheData = OneCacheData;
    MH4N_LOG(Info, "RHI", "rhi: one shader or pipeline build at a time, from any thread (a PowerVR: its compiler crashed "
                          "building two at once){}", env != nullptr ? " (MH4N_ONE_COMPILE)" : "");
}

} // namespace

Result<std::shared_ptr<Backend>> CreateBackend(std::shared_ptr<Instance> instance, const BackendOptions& options) {
    if (instance == nullptr) {
        return Error{"CreateBackend: no instance"};
    }
    ::plume::VulkanInterface* interface = instance->impl().vulkan();
    const VkSurfaceKHR surface = VulkanSurface(options.surface);

    Result<CapabilityMask> combined = core::CombineMasks(std::getenv("MH4N_RHI_MASK"), options.mask);
    if (!combined.ok()) {
        return Error{combined.error()};
    }
    const CapabilityMask mask = *combined;

    // Every physical device, in the order of vkEnumeratePhysicalDevices on the instance.
    u32 count = 0;
    vkEnumeratePhysicalDevices(interface->instance, &count, nullptr);
    std::vector<VkPhysicalDevice> devices(count);
    if (count > 0) {
        vkEnumeratePhysicalDevices(interface->instance, &count, devices.data());
        devices.resize(count);
    }
    if (devices.empty()) {
        return Error{"the Vulkan loader lists no device (no driver installed for this machine's GPU?)"};
    }
    std::vector<Probe> probes;
    std::vector<core::DeviceCandidate> candidates;
    for (u32 i = 0; i < devices.size(); ++i) {
        Probe probe = ProbePhysicalDevice(devices[i], i, surface);
        Capabilities masked = probe.caps;
        ApplyMask(masked, mask);
        probe.candidate.capability_bits = CountBits(probe.caps, mask);
        candidates.push_back(probe.candidate);
        probes.push_back(std::move(probe));
    }

    std::string wanted = options.device;
    if (wanted.empty()) {
        if (const char* env = std::getenv("MH4N_VULKAN_DEVICE")) {
            wanted = env;
        }
    }
    const core::DeviceChoice choice = core::ChooseDevice(candidates, wanted, surface != VK_NULL_HANDLE);
    for (const std::string& line : choice.log) {
        MH4N_LOG(Info, "RHI", "rhi: {}", line);
    }
    if (!choice.ok) {
        return Error{choice.error};
    }
    const Probe& probe = probes[choice.index];

    // What to enable: the core features the capabilities use, and the optional extensions that are kept
    // (descriptor indexing, scalar block layout, robustness2, buffer device address, sampler mirror
    // clamp, sample locations, load/store op none), plus the ones the capabilities use and the mask
    // leaves on. Never ray tracing.
    ::plume::VulkanDeviceExtras extras;
    std::string failure;
    extras.error = &failure;
    extras.surface = surface;
    extras.physicalDeviceIndex = static_cast<int32_t>(choice.index);
    VkPhysicalDeviceFeatures wanted_features = {};
    wanted_features.fragmentStoresAndAtomics = VK_TRUE;
    wanted_features.vertexPipelineStoresAndAtomics = VK_TRUE;
    wanted_features.geometryShader = mask.Has(Cap::GeometryShader) ? VK_FALSE : VK_TRUE;
    wanted_features.shaderClipDistance = VK_TRUE;
    wanted_features.samplerAnisotropy = VK_TRUE;
    wanted_features.imageCubeArray = VK_TRUE;
    wanted_features.logicOp = mask.Has(Cap::LogicOp) ? VK_FALSE : VK_TRUE;
    wanted_features.textureCompressionBC = mask.Has(Cap::Bc7) ? VK_FALSE : VK_TRUE;
    extras.coreFeatures = wanted_features;
    std::vector<std::string> extensions = {
        VK_EXT_DESCRIPTOR_INDEXING_EXTENSION_NAME,
        VK_EXT_SCALAR_BLOCK_LAYOUT_EXTENSION_NAME,
        VK_EXT_ROBUSTNESS_2_EXTENSION_NAME,
        VK_KHR_BUFFER_DEVICE_ADDRESS_EXTENSION_NAME,
        VK_KHR_SAMPLER_MIRROR_CLAMP_TO_EDGE_EXTENSION_NAME,
        VK_EXT_SAMPLE_LOCATIONS_EXTENSION_NAME,
        VK_EXT_LOAD_STORE_OP_NONE_EXTENSION_NAME,
    };
    if (!mask.Has(Cap::Interlock)) extensions.push_back(VK_EXT_FRAGMENT_SHADER_INTERLOCK_EXTENSION_NAME);
    if (!mask.Has(Cap::IndexUint8)) extensions.push_back(VK_EXT_INDEX_TYPE_UINT8_EXTENSION_NAME);
    if (!mask.Has(Cap::CustomBorderColor)) extensions.push_back(VK_EXT_CUSTOM_BORDER_COLOR_EXTENSION_NAME);
#if defined(__ANDROID__)
    // Images the system's other graphics read (gpu/backend/shared: the app shows the screens from them) and the sync
    // file of a fence (plume patch 16). Their other dependencies are core from Vulkan 1.1 on; an older device goes
    // without them, and so does a run with MH4N_NO_SHARED_IMAGES=1.
    if (probe.caps.api_version >= MakeApi(1, 1) && std::getenv("MH4N_NO_SHARED_IMAGES") == nullptr) {
        extensions.push_back("VK_ANDROID_external_memory_android_hardware_buffer");
        extensions.push_back(VK_EXT_QUEUE_FAMILY_FOREIGN_EXTENSION_NAME);
        extensions.push_back(VK_KHR_EXTERNAL_FENCE_FD_EXTENSION_NAME);
    }
#endif
    if (surface != VK_NULL_HANDLE) {
        if (!mask.Has(Cap::PresentWait)) {
            extensions.push_back(VK_KHR_PRESENT_ID_EXTENSION_NAME);
            extensions.push_back(VK_KHR_PRESENT_WAIT_EXTENSION_NAME);
        }
        extensions.push_back(VK_GOOGLE_DISPLAY_TIMING_EXTENSION_NAME);
    }
    extras.optionalExtensions = extensions;
    // (timeline semaphores only on Vulkan 1.2: plume enables them as core, without VK_KHR_timeline_semaphore, so on a 1.1
    // driver vkGetSemaphoreCounterValue was null, a crash at the first frame on an Adreno 730 (4u-native issue #1); 1.1 uses fences)
    extras.timelineSemaphore = !mask.Has(Cap::Timeline) && probe.caps.api_version >= MakeApi(1, 2);
    // The allocator's blocks (plume patch 18): 32 MiB, not VMA's 256. A memory type's blocks then grow by 4, 8, 16 and
    // 32 MiB, not 32, 64, 128 and 256, and a phone holds a block whole however little of it is used (the Moto at 3x held
    // 256 MB of blocks for 120 MB of allocations). MH4N_VMA_BLOCK_MB=<n> another size, 0 VMA's own.
    extras.allocatorBlockSize = 32ull << 20;
    if (const char* env = std::getenv("MH4N_VMA_BLOCK_MB")) {
        extras.allocatorBlockSize = static_cast<u64>(std::strtoull(env, nullptr, 10)) << 20;
    }
    // The queues' global priority (plume patch 19), MH4N_QUEUE_PRIORITY=low|medium|high: with low, the work of the app's
    // own GL context (the window's picture: the screens and the touch controls) goes ahead of the renderer's queued
    // frames on the GPU instead of after them. Unset: none asked (the driver's default, medium).
    if (const char* env = std::getenv("MH4N_QUEUE_PRIORITY")) {
        const std::string_view v(env);
        extras.queueGlobalPriority = v == "low" ? VK_QUEUE_GLOBAL_PRIORITY_LOW_KHR
                                     : v == "medium" ? VK_QUEUE_GLOBAL_PRIORITY_MEDIUM_KHR
                                     : v == "high"   ? VK_QUEUE_GLOBAL_PRIORITY_HIGH_KHR
                                                     : 0;
        MH4N_LOG(Info, "RHI", "rhi: the queues' global priority asked: {} ({})", env, extras.queueGlobalPriority);
    }

    std::unique_ptr<::plume::RenderDevice> device_owner = interface->createDeviceEx(std::string(), extras);
    if (device_owner == nullptr) {
        return Error{fmt::format("cannot make the device {} ({}): {}", probe.candidate.index, probe.candidate.Label(),
                                 failure.empty() ? "unknown failure" : failure)};
    }
    auto* device = static_cast<::plume::VulkanDevice*>(device_owner.get());

    auto impl = std::make_shared<Backend::Impl>();
    impl->instance = std::move(instance);
    impl->surface = surface;
    impl->limits = probe.limits;
    impl->physical_device = device->physicalDevice;
    impl->device_owner = std::move(device_owner);
    impl->device = device;
    impl->enabled_extensions = device->enabledExtensionNames;
    if (extras.queueGlobalPriority != 0) {
        const bool given = std::any_of(impl->enabled_extensions.begin(), impl->enabled_extensions.end(), [](const auto& e) {
            return std::string_view(e).find("global_priority") != std::string_view::npos;
        });
        MH4N_LOG(Info, "RHI", "rhi: the queues' global priority {}", given ? "given" : "not offered or not permitted: none");
    }
    std::sort(impl->enabled_extensions.begin(), impl->enabled_extensions.end());

    // The final capabilities: the query, then the mask, then what the device really enabled.
    Capabilities caps = probe.caps;
    ApplyMask(caps, mask);
    const ::plume::RenderDeviceCapabilities& enabled = device->getCapabilities();
    caps.interlock = caps.interlock && enabled.fragmentShaderInterlock;
    caps.index_uint8 = caps.index_uint8 && enabled.indexTypeUint8;
    caps.custom_border_color = caps.custom_border_color && enabled.customBorderColor;
    caps.timeline = caps.timeline && enabled.timelineSemaphore;
    caps.logic_op = caps.logic_op && device->enabledCoreFeatures.logicOp;
    caps.bc7 = caps.bc7 && device->enabledCoreFeatures.textureCompressionBC;
    caps.geometry_shader = caps.geometry_shader && device->enabledCoreFeatures.geometryShader != VK_FALSE;
    caps.clip_distance = caps.clip_distance && device->enabledCoreFeatures.shaderClipDistance != VK_FALSE;
    impl->present_wait_available =
        core::PresentWaitAvailable(surface != VK_NULL_HANDLE, caps.present_wait, enabled.presentWait);
    impl->display_timing_available = surface != VK_NULL_HANDLE && enabled.displayTiming;
    impl->present_wait_measures_display =
        core::PresentWaitMeasuresDisplay(impl->present_wait_available, caps.driver_id, caps.driver_name);
    impl->caps = std::move(caps);

    // The queue (one virtual queue on the direct family), its submit lock, the timeline.
    impl->queue_owner = impl->device_owner->createCommandQueue(::plume::RenderCommandListType::DIRECT);
    if (impl->queue_owner == nullptr) {
        return Error{"cannot make the command queue"};
    }
    impl->queue = static_cast<::plume::VulkanCommandQueue*>(impl->queue_owner.get());
    impl->queue_mutex = impl->queue->queue->mutex.get();
    impl->vk_queue = impl->queue->queue->vk;
    impl->queue_family = impl->queue->familyIndex;
    {
        // The vendored backend leaves the family at 0 when none matches its pick: check what it really chose.
        u32 family_count = 0;
        vkGetPhysicalDeviceQueueFamilyProperties(impl->physical_device, &family_count, nullptr);
        std::vector<VkQueueFamilyProperties> families(family_count);
        vkGetPhysicalDeviceQueueFamilyProperties(impl->physical_device, &family_count, families.data());
        if (impl->queue_family >= family_count || !core::IsDirectQueueFamily(families[impl->queue_family].queueFlags)) {
            return Error{fmt::format("the queue family {} that the device was given is not a graphics and compute family",
                                     impl->queue_family)};
        }
    }
    if (impl->caps.timeline) {
        impl->timeline_owner = impl->device_owner->createTimelineSemaphore(0);
        if (impl->timeline_owner == nullptr) {
            MH4N_LOG(Warning, "RHI", "rhi: the timeline semaphore could not be made; submissions use fences");
            impl->caps.timeline = false;
        } else {
            impl->timeline = static_cast<::plume::VulkanCommandSemaphore*>(impl->timeline_owner.get())->vk;
        }
    }
    if (surface != VK_NULL_HANDLE) {
        VkBool32 supported = VK_FALSE;
        vkGetPhysicalDeviceSurfaceSupportKHR(impl->physical_device, impl->queue_family, surface, &supported);
        if (!supported) {
            return Error{"the queue family chosen for the device cannot present to the surface"};
        }
    }

    const Capabilities& c = impl->caps;
    {  // (the SPIR-V the shaders are compiled to: 1.3 below Vulkan 1.2, mh4n/spirv_target.h; MH4N_SPIRV=1.3|1.5 a test)
        const char* env = std::getenv("MH4N_SPIRV");
        const bool v13 = env != nullptr && std::string(env) == "1.3"   ? true
                         : env != nullptr && std::string(env) == "1.5" ? false
                                                                       : c.api_version < MakeApi(1, 2);
        gpu::g_spirv_1_3.store(v13, std::memory_order_relaxed);
        MH4N_LOG(Info, "RHI", "rhi: shaders compiled to SPIR-V {} (Vulkan {})", v13 ? "1.3" : "1.5", v13 ? "1.1" : "1.2");
    }
    MH4N_LOG(Info, "RHI", "rhi: mask {}", mask.bits != 0 ? mask.ToString() : std::string("none"));
    MH4N_LOG(Info, "RHI", "rhi: device {} \"{}\" driver \"{}\" (id {}) api {}.{}.{}, queue family {}, {}",
             c.device_index, c.device_name, c.driver_name, c.driver_id, (c.api_version >> 22) & 0x7F,
             (c.api_version >> 12) & 0x3FF, c.api_version & 0xFFF, impl->queue_family,
             surface != VK_NULL_HANDLE ? "with a surface" : "no surface");
    MH4N_LOG(Info, "RHI",
             "rhi: caps d24s8={} interlock={} index_uint8={} custom_border_color={} triangle_fans={} logic_op={} "
             "dynamic_rendering={} "
             "pipeline_library={} eds3_blend={} bc7={} timeline={} present_wait={} direct_upload={} geometry_shader={}",
             c.d24s8, c.interlock, c.index_uint8, c.custom_border_color, c.triangle_fans, c.logic_op,
             c.dynamic_rendering, c.pipeline_library, c.eds3_blend, c.bc7, c.timeline, c.present_wait, c.direct_upload,
             c.geometry_shader);
    MH4N_LOG(Info, "RHI", "rhi: device extensions enabled: {}", core::JoinNames(impl->enabled_extensions));

    {  // (which GPU and which driver run, as the driver tells it: to the host's hooks, driver_hooks.h)
        MadeDevice made;
        made.device_name = c.device_name;
        made.driver_name = c.driver_name;
        made.vendor_id = c.vendor_id;
        made.driver_id = c.driver_id;
        made.api_version = c.api_version;
        VkPhysicalDeviceProperties props = {};
        vkGetPhysicalDeviceProperties(impl->physical_device, &props);
        made.driver_version = props.driverVersion;
        if (!c.driver_name.empty()) {  // (the driver's properties answered the probe: its info as well)
            VkPhysicalDeviceDriverProperties driver = {};
            driver.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_DRIVER_PROPERTIES;
            VkPhysicalDeviceProperties2 props2 = {};
            props2.sType = VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2;
            props2.pNext = &driver;
            vkGetPhysicalDeviceProperties2(impl->physical_device, &props2);
            // (Qualcomm's is several lines, "Label: value", some of them empty: one line here, without those)
            const std::string info = driver.driverInfo;
            for (size_t from = 0; from < info.size();) {
                size_t end = info.find('\n', from);
                if (end == std::string::npos) end = info.size();
                std::string line = info.substr(from, end - from);
                from = end + 1;
                while (!line.empty() && (line.back() == ' ' || line.back() == '\r' || line.back() == '\t')) line.pop_back();
                if (line.empty() || line.back() == ':') continue;
                made.driver_info += (made.driver_info.empty() ? "" : ", ") + line;
            }
        }
        // (a Mali driver without driver properties, an old one, tells its release only in driverVersion: Arm's rNpM is
        // VK_MAKE_VERSION(N, M, 0), r34p0 0x8800000)
        constexpr u32 kVendorArm = 0x13B5;
        const std::string release = c.driver_name.empty() && c.vendor_id == kVendorArm
                                        ? fmt::format(" (r{}p{})", made.driver_version >> 22, (made.driver_version >> 12) & 0x3FF)
                                        : std::string();
        MH4N_LOG(Info, "RHI", "rhi: driver info \"{}\", version {:#x}{}", made.driver_info, made.driver_version, release);
        core::HostDeviceMade(made);
    }
    OneCompileAtATime(c);

    return std::shared_ptr<Backend>(new Backend(std::move(impl)), ReleaseWithLastHandle);
}

} // namespace mh4n::gpu::rhi
