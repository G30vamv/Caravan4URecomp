package com.mh4u.port;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.libsdl.app.SDLActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * MH4U: the SDL activity that starts the native runtime (libmain.so, main in app_native/android_main.cpp).
 *
 * The player's files go in the app's external folder (Android/data/<package>/files):
 *   launch.txt   game=, code=, user= (GameFolderActivity writes it)
 *   user/        saves, extra data, mh4u.ini, load/mods
 *   log.txt      this session's log (Share log)
 */
public class GameActivity extends SDLActivity {
    private static final String TAG = "MH4U";

    /** GameFolderActivity, the entry, checked everything in this process and started the game (startGame). */
    static volatile boolean entered;

    @Override
    protected String[] getLibraries() {
        return new String[] { "SDL3", "main" };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // (who started it: "com.android.shell" for adb's am start, the test runs' way with a launch.txt of their own)
        android.net.Uri referrer = getReferrer();
        String by = referrer != null ? referrer.getHost() : null;
        if (!entered && !"com.android.shell".equals(by)) {
            // A start that didn't come through the entry: Android bringing the game's task back after its process ended
            // (Recents), a controller's USB start, another app. The entry's checks must come first (the app's folder, the
            // save folder's start gate with its in-use warning, the notices, the game's files and library), and SDL is made
            // only once in a process: this one ends at once, before the game runs, and PhoenixActivity opens the entry
            super.onCreate(savedInstanceState);  // (Android wants it; with finish() here no surface comes, so no game)
            Log.i(TAG, "a start without the entry (" + getIntent().getAction() + ", by " + by + "): through the entry");
            Intent intent = new Intent(this, PhoenixActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            intent.putExtra(PhoenixActivity.EXTRA_PID, Process.myPid());
            startActivity(intent);
            overridePendingTransition(0, 0);
            finish();
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(() -> Process.killProcess(Process.myPid()), 200);
            return;
        }
        getExternalFilesDir(null);  // (makes the folder, so the native side and adb can find it)
        if (!entered) AppHome.ensure(this);  // (a test run started with adb: the app's folder checked, as the entry does)
        SaveFolder.applyPending(this);  // (Settings -> Save folder, before the game reads the save: done by the gate already)
        SaveActivity.applyPending(this);  // (an imported save, before the game reads it: done by the gate already)
        ExtraImportActivity.applyPending(this);  // (imported event quests, before the game reads its extra data)
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        pickRefreshRate();
    }

    @Override
    protected void onResume() {
        super.onResume();
        pickRefreshRate();
    }

    /**
     * "Guardar y reiniciar" del menú de opciones (runtime/ui.c restart_application, por JNI desde el hilo de SDL):
     * PhoenixActivity, en su propio proceso, espera a que este termine (el código nativo hace exit(0) al volver de acá,
     * y su atexit guarda la caché de pipelines) y lanza la app de nuevo. Si no se puede, una excepción: el menú dice
     * entonces que el reinicio falló y el juego sigue.
     */
    public static void restartApp() {
        SDLActivity activity = mSingleton;
        if (activity == null) throw new IllegalStateException("restartApp: no activity");
        Intent intent = new Intent(activity, PhoenixActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(PhoenixActivity.EXTRA_PID, Process.myPid());
        activity.startActivity(intent);
        Log.i(TAG, "restart: PhoenixActivity, pid " + Process.myPid());
    }

    /** Los carteles del programa (SDL_ShowMessageBox) con los colores de las ventanas del juego. */
    @Override
    protected void messageboxCreateAndShow(Bundle args) {
        final int wine = Color.rgb(38, 18, 14), cream = Color.rgb(240, 228, 200), gold = Color.rgb(226, 182, 92);
        final int bronze = Color.rgb(62, 38, 22), edge = Color.rgb(196, 150, 70);
        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setOnDismissListener(d -> {
            synchronized (messageboxSelection) {
                messageboxSelection.notify();
            }
        });

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(16), dp(24), dp(18));
        GradientDrawable plate = new GradientDrawable();
        plate.setColor(wine);
        plate.setStroke(dp(2), edge);
        plate.setCornerRadius(dp(6));
        box.setBackground(plate);

        TextView title = new TextView(this);
        title.setText(args.getString("title"));
        title.setTextColor(gold);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        box.addView(title);
        View rule = new View(this);
        rule.setBackgroundColor(edge);
        LinearLayout.LayoutParams ruleSize = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(1));
        ruleSize.setMargins(0, dp(10), 0, dp(14));
        box.addView(rule, ruleSize);
        TextView message = new TextView(this);
        message.setText(args.getString("message"));
        message.setTextColor(cream);
        message.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        message.setGravity(Gravity.CENTER);
        box.addView(message);

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.setPadding(0, dp(16), 0, 0);
        int[] ids = args.getIntArray("buttonIds");
        String[] texts = args.getStringArray("buttonTexts");
        Button first = null;
        for (int i = 0; i < texts.length; i++) {
            final int id = ids[i];
            Button button = new Button(this);
            button.setText(texts[i]);
            button.setAllCaps(false);
            button.setTextColor(cream);
            GradientDrawable face = new GradientDrawable();
            face.setColor(bronze);
            face.setStroke(dp(2), edge);
            face.setCornerRadius(dp(6));
            button.setBackground(face);
            button.setOnClickListener(v -> {
                messageboxSelection[0] = id;
                dialog.dismiss();
            });
            LinearLayout.LayoutParams size = new LinearLayout.LayoutParams(dp(120), dp(44));
            size.setMargins(dp(6), 0, dp(6), 0);
            row.addView(button, size);
            if (first == null) first = button;
        }
        box.addView(row);
        final Button main = first;
        dialog.setOnKeyListener((d, key, event) -> {  // (un joystick: A o B)
            if (main == null || (key != KeyEvent.KEYCODE_BUTTON_A && key != KeyEvent.KEYCODE_BUTTON_B
                    && key != KeyEvent.KEYCODE_ENTER && key != KeyEvent.KEYCODE_ESCAPE)) return false;
            if (event.getAction() == KeyEvent.ACTION_UP) main.performClick();
            return true;
        });
        dialog.setContentView(box);
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setLayout((int) (getResources().getDisplayMetrics().widthPixels * .52f), WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    /** El informe de entrada del log (app_native/controls.cpp, por JNI desde el hilo de SDL), como el del port de MHGU:
     *  los dispositivos de entrada como los lista Android y las teclas de mando de los que no se leen como mando. "" si
     *  nada cambió. */
    public static String inputReport(boolean changed) {
        return org.libsdl.app.SDLControllerManager.inputReport(changed);
    }

    /** Teclado y mouse conectados (app_native/controls.cpp, por JNI desde el hilo de SDL), como en el port de MHGU: 1 un
     *  teclado físico con letras, 2 un mouse, los dos sumados. Con los dos, las opciones muestran las teclas y el mouse. */
    public static int keyboardMouse() {
        return org.libsdl.app.SDLControllerManager.keyboardMouse();
    }

    /** Ajustes -> Licencias (runtime/ui.c show_licenses, por JNI desde el hilo de SDL). */
    public static void showLicenses() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, LicensesActivity.class));
    }

    /** Settings -> Import save. */
    public static void showSaveImport() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, SaveActivity.class));
    }

    /** Settings -> Import DLC and event quests (S37). */
    public static void showExtraImport() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, ExtraImportActivity.class));
    }

    /** Settings -> Shortcut with your image (S56). */
    public static void showShortcut() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, ShortcutActivity.class));
    }

    /** Settings -> Save folder. */
    public static void showSaveFolder() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, SaveFolderActivity.class));
    }

    /** Settings -> Export save. */
    public static void showSaveExport() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, SaveActivity.class).putExtra(SaveActivity.EXTRA_EXPORT, true));
    }

    /** Settings -> Graphics & Audio -> Import a driver (app_native/gpu_driver.cpp): DriverActivity, over the game. */
    public static void showDriverImport() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, DriverActivity.class));
    }

    /** Settings -> Cheats -> Import cheats (app_native/content.cpp): ImportActivity, over the game. */
    public static void showCheatImport() { showImport(ImportActivity.CHEATS); }

    /** The layout editor's Picture -> Add pictures (app_native/touch.cpp img_tap): the buttons' own pictures. */
    public static void importPictures() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, PicturesActivity.class));
    }

    /** Settings -> Mods -> Add a mod (.zip / folder) (app_native/content.cpp): ImportActivity, over the game. */
    public static void showModImport() { showImport(ImportActivity.MOD_ZIP); }
    public static void showModFolderImport() { showImport(ImportActivity.MOD_FOLDER); }

    private static void showImport(int kind) {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, ImportActivity.class).putExtra(ImportActivity.KIND, kind));
    }

    /** Ajustes -> Compartir registro. */
    public static void showShareLog() {
        SDLActivity activity = mSingleton;
        if (activity != null) activity.startActivity(new Intent(activity, LogShareActivity.class));
    }

    /** El juego se cierra por un error (runtime/platform/android.c): la pantalla para compartir el registro, en su proceso. */
    public static void crashReport() {
        SDLActivity activity = mSingleton;
        if (activity == null) throw new IllegalStateException("crashReport: no activity");
        Intent intent = new Intent(activity, LogShareActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.putExtra(LogShareActivity.EXTRA_CRASH, true);
        activity.startActivity(intent);
    }

    /** LAN (runtime/net/ldn.c): sin este permiso, muchos teléfonos descartan por Wi-Fi los paquetes de búsqueda de sala. */
    public static void lanSearch(boolean on) {
        SDLActivity activity = mSingleton;
        if (activity == null) return;
        try {
            synchronized (GameActivity.class) {
                if (lanLock == null) {
                    android.net.wifi.WifiManager wifi = (android.net.wifi.WifiManager) activity.getApplicationContext().getSystemService(WIFI_SERVICE);
                    if (wifi == null) return;
                    lanLock = wifi.createMulticastLock("mh4u-lan");
                    lanLock.setReferenceCounted(false);
                }
                if (on) lanLock.acquire();
                else if (lanLock.isHeld()) lanLock.release();
                Log.i(TAG, "LAN: Wi-Fi broadcasts " + (on ? "on" : "off"));
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "LAN: " + e);
        }
    }
    private static android.net.wifi.WifiManager.MulticastLock lanLock;

    /** Settings -> Build the game code: the on-phone builder, over the game (which starts again to load what it made). */
    public static void showBuilder() {
        SDLActivity activity = mSingleton;
        if (activity != null)
            activity.startActivity(new Intent(activity, BuilderActivity.class).putExtra(BuilderActivity.EXTRA_FROM_GAME, true));
    }

    /** Ajustes -> Carpeta del juego. */
    public static void showGameFolder() {
        SDLActivity activity = mSingleton;
        if (activity != null) {
            Intent intent = new Intent(activity, GameFolderActivity.class);
            intent.putExtra(GameFolderActivity.EXTRA_CHANGE, true);
            activity.startActivity(intent);
        }
    }

    /**
     * Cuánto antes de un vsync hay que entregar un búfer para que se vea en él (Display.getPresentationDeadlineNanos):
     * el margen de los presents con hora (present_pacing.cpp). 0 si no se sabe.
     */
    public static long presentationDeadlineNs() {
        SDLActivity activity = mSingleton;
        if (activity == null) return 0;
        try {
            Display display = Build.VERSION.SDK_INT >= 30 ? activity.getDisplay() : activity.getWindowManager().getDefaultDisplay();
            return display != null ? display.getPresentationDeadlineNanos() : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    private static volatile float frameCap;  // (el límite de FPS de los ajustes; 0: aún no se sabe, o sin límite)

    /** El límite de FPS cambió (runtime/ui.c): la pantalla lo sigue. */
    public static void setFrameCap(float fps) {
        frameCap = fps;
        SDLActivity activity = mSingleton;
        if (activity instanceof GameActivity) activity.runOnUiThread(((GameActivity) activity)::pickRefreshRate);
    }

    /**
     * La tasa de refresco más baja que alcanza para el límite de FPS, nunca menos de 60: una pantalla a 120 Hz con el juego
     * a 60 gasta batería y calienta el teléfono sin mostrar nada más. Sin límite conocido, la más alta.
     */
    private void pickRefreshRate() {
        try {
            Display display = Build.VERSION.SDK_INT >= 30 ? getDisplay() : getWindowManager().getDefaultDisplay();
            if (display == null) return;
            Display.Mode current = display.getMode(), best = null, fastest = current;
            float want = frameCap > 0 ? Math.max(frameCap, 60) - .5f : Float.MAX_VALUE;
            for (Display.Mode m : display.getSupportedModes()) {
                if (m.getPhysicalWidth() != current.getPhysicalWidth() || m.getPhysicalHeight() != current.getPhysicalHeight()) continue;
                if (m.getRefreshRate() > fastest.getRefreshRate()) fastest = m;
                if (m.getRefreshRate() >= want && (best == null || m.getRefreshRate() < best.getRefreshRate())) best = m;
            }
            if (best == null) best = fastest;
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.preferredDisplayModeId = best.getModeId();
            lp.preferredRefreshRate = best.getRefreshRate();
            getWindow().setAttributes(lp);
            Log.i(TAG, "display mode " + best.getPhysicalWidth() + "x" + best.getPhysicalHeight() + " @ " + best.getRefreshRate());
        } catch (Exception e) {
            Log.w(TAG, "refresh rate: " + e);
        }
    }
}
